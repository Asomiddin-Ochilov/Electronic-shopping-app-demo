
import React from 'react';
import './App.css';
import Header from "./components/header/header";
import BannerPage from "./components/bannerBlock/bannerPage";
function App() {
  return (
    <div className="App">
     <Header/>
    <BannerPage/>
    </div>
  );
}

export default App;
